public class Main {
    public static void main(String[] args) {

        TradesPerson trper1 = new TradesPerson("Trader Tim ", "Wood",17);
        trper1.print();

        Baker baker1;
        baker1 = new Baker("Baker bob");
        baker1.print();
    }
}