public class Baker extends  TradesPerson {

    String speciality;

    Baker(String name) {
        super(name, trade, wage);

    }

    @Override
    void print() {
        super.print();
        System.out.println("speciality: " + speciality);

    }
}
