window.onload = () =>{
   const myVideo = document.querySelector('video')
   const play_btn = document.getElementById('playPause')
   
   play_btn.addEventListener('click', ()=>{
      
      if(myVideo.paused) {
         myVideo.play()
         myVideo.paused = false
      }
      else {
         myVideo.pause()
         myVideo.paused = true
      }
   })
}